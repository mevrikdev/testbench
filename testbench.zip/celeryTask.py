from celery import Celery
from log_handler.LogHandler import LogHandler

app = Celery(
    'process_task',
    broker="redis://localhost:6379/0"
)


@app.task
def process_task(path):
    LogHandler(path).isfileOrDir()




